import React from "react";
import { Helmet } from "react-helmet";

const Contact = () => {
  return (
    <div>
      <h1>This is Contact page</h1>
    </div>
  );
};

export default Contact;
